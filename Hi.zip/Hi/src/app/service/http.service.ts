import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { VehicleFamilyModel } from 'src/app/entity/VehicleFam';
import { CriteriaTypeModel} from 'src/app/entity/CriteriaType';

type EntityResponseType = HttpResponse<VehicleFamilyModel[]>;
type EntityResponseType1 = HttpResponse<CriteriaTypeModel[]>;
@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private http:HttpClient) { }
  getAll():Observable<EntityResponseType>{
    return this.http.get<VehicleFamilyModel[]>("http://127.0.0.1:5000/api/vehiclefamily", {observe: 'response'});
}
getAll1():Observable<EntityResponseType1>{
  return this.http.get<CriteriaTypeModel[]>("http://127.0.0.1:5000/api/criteriatype", {observe: 'response'});
}

}
