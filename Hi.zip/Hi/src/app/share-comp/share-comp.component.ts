import { Component, DoCheck, OnInit } from '@angular/core';
import { VehicleFamilyModel } from 'src/app/entity/VehicleFam';
import {CriteriaTypeModel} from 'src/app/entity/CriteriaType';
import { HttpService } from 'src/app/service/http.service';
@Component({
  selector: 'app-share-comp',
  templateUrl: './share-comp.component.html',
  styleUrls: ['./share-comp.component.css']
})
export class ShareCompComponent implements OnInit{
  vehFam:VehicleFamilyModel[];
  criType:CriteriaTypeModel[];
  dropdownList = [];
  dropdownList1 = [];
  id : any;
  hey= "";
  hey1= "";
  constructor(private service:HttpService) {
   } 
 ngOnInit() { 
    this.service.getAll().subscribe(data => {
     this.vehFam = data.body;

   for(var i=0; i<this.vehFam.length;i++){
    this.dropdownList.push ( {item_id: this.vehFam[i].vehicle_family_id, item_text: this.vehFam[i].vehicle_family_name});
   // this.dropdownList = [ { item_id : this.vehFam[1].vehicle_family_id, item_text: this.vehFam[1].vehicle_family_name } ];
   console.log(this.dropdownList);
  }
 }); 
 this.service.getAll1().subscribe(data => {
  this.criType = data.body;

for(var i=0; i<this.criType.length;i++){
 this.dropdownList1.push ( {item_id: this.criType[i].criteria_type_id, item_text: this.criType[i].criteria_type});
console.log(this.dropdownList1);
}
}); 

  }
  onChange(event){
    console.log(event.target.value);
this.hey = event.target.value;
  }
  onChange1(event){
    console.log(event.target.value);
this.hey1 = event.target.value;
  }
}
