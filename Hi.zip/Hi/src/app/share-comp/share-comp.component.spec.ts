import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShareCompComponent } from './share-comp.component';

describe('ShareCompComponent', () => {
  let component: ShareCompComponent;
  let fixture: ComponentFixture<ShareCompComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShareCompComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShareCompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
