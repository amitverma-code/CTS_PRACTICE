export interface CriteriaTypeModel{
    criteria_type_id: string;
    criteria_type: string;
    
}