export interface VehicleFamilyModel{
    vehicle_family_id: string;
    vehicle_family_name: string;
    
}